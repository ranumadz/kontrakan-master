foto kamar mandi img
