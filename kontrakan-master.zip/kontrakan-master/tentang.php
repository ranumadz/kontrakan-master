<?php

include 'template/header.php'
?>
<div class="container">

    <h5>Tentang Kontrakin</h5>
    <hr>
    <p>Kontrakin adalah website yang menyajikan informasi Kontrakan dengan fasilitas lainnya, harga dan foto kamar yang sedetail mungkin
        seperti aslinya, anda bisa mendaftar sebagai pencari kontrakan ataupun penyedia Kontrakan
    </p>
</div>



<?php
include "template/footer.php";
?>