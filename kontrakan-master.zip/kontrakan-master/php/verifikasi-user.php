<?php
include("koneksi.php");


if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id']) && isset($_GET['action'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    // Lakukan verifikasi berdasarkan tindakan (approve/reject)
    if ($action == 'Setujui') {
        $status_verifikasi = 1; // Ubah status verifikasi menjadi 1 (disetujui)
    } else if ($action == 'Block') {
        $status_verifikasi = 2; // Ubah status verifikasi menjadi 2 (ditolak)
    }

    $sql = "UPDATE user SET status_verifikasi = ? WHERE id = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param('ii', $status_verifikasi, $id);

    if ($stmt->execute()) {
        // Redirect kembali ke halaman admin setelah proses verifikasi
        header("Location: admin_verifikasi.php");



        exit();
    } else {
        echo "Terjadi kesalahan: " . $stmt->error;
    }
}
