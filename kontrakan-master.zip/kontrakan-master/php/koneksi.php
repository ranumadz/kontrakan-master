<?php
$koneksi = mysqli_connect("localhost", "root", "", "simkost");

// if (!$koneksi) {
//     echo "gagal terhubung ke database";
// } else {
//     echo "terhubung";
// }
