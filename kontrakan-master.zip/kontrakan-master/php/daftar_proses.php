<?php
include("koneksi.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nama_lengkap = $_POST["nama_lengkap"];
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $no_hp = $_POST["no_hp"];
    $pekerjaan = $_POST["pekerjaan"];
    $jenis_kelamin = $_POST["jenis_kelamin"];
    $roles = $_POST["roles"];
    $foto_ktp = $_FILES["foto_ktp"]['name'];
    $foto_profil = $_FILES["foto_profil"]['name'];
    $sumber1 = $_FILES["foto_ktp"]['tmp_name'];
    $sumber2 = $_FILES["foto_profil"]['tmp_name'];

    move_uploaded_file($sumber1, '../img/ktp/' . $foto_ktp);
    move_uploaded_file($sumber2, '../img/profil/' . $foto_profil);

    $query = "INSERT INTO user (nama_lengkap, email, username, password, no_hp, pekerjaan, jenis_kelamin, foto_ktp, foto_profil, roles, status_verifikasi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Persiapan statement
    $stmt = mysqli_prepare($koneksi, $query);

    // Bind parameter
    mysqli_stmt_bind_param($stmt, "ssssssssssi", $nama_lengkap, $email, $username, $password, $no_hp, $pekerjaan, $jenis_kelamin, $foto_ktp, $foto_profil, $roles, $status_verifikasi);

    // Status verifikasi default: 0 (belum diverifikasi)
    $status_verifikasi = 0;

    // Eksekusi statement
    if (mysqli_stmt_execute($stmt)) {
        // Redirect ke halaman sukses pendaftaran menggunakan JavaScript
        echo "<script>window.location.href='../sukses_pendaftaran.php';</script>";
        exit();
    } else {
        echo "Terjadi kesalahan: " . mysqli_error($koneksi);
    }
}
?>
