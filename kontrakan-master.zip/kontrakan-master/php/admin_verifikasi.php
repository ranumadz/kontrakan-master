<?php
include("koneksi.php");

// Tampilkan pengguna yang belum diverifikasi
$data = mysqli_query($koneksi, "SELECT * FROM user WHERE status_verifikasi = 0");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Verifikasi</title>
</head>

<body>
    <h1>Daftar Pengguna yang Menunggu Verifikasi</h1>
    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>Username</th>
                <th>Email</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $n = 0;
            while ($d = mysqli_fetch_array($data)) {
                $n++;
            ?>
                <tr>
                    <td><?php echo $n ?></td>
                    <td><?php echo $d['nama_lengkap'] ?></td>
                    <td><?php echo $d['username'] ?></td>
                    <td><?php echo $d['email'] ?></td>
                    <td>
                        <a href="verifikasi-user.php?id=<?php echo $d['id']; ?>&action=approve">Setujui</a> |
                        <a href="verifikasi-user.php?id=<?php echo $d['id']; ?>&action=reject">Block</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>

</html>