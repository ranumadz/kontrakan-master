</div>
<style>
    .copyright {
        padding: 50px;
    }
</style>
<footer style="margin-top:100px;color:white" class="sticky-footer bg-danger">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Sistem Informasi Kontrakan Nikmatul Saumi | 2024</span>
        </div>
    </div>
</footer>
</body>