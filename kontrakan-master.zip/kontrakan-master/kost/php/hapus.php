<?php
include "../../php/koneksi.php";

if (isset($_GET['id_kost'])) {
    $id_kost = $_GET['id_kost'];
    echo "ID Kost: " . $id_kost . "<br>";

    // Mulai transaksi
    mysqli_begin_transaction($koneksi);

    // Hapus baris terkait di tabel 'kamar'
    $query_delete_kamar = "DELETE FROM kamar WHERE id_kost='$id_kost'";
    $data_kamar = mysqli_query($koneksi, $query_delete_kamar);

    if ($data_kamar) {
        // Hapus baris di tabel 'kost'
        $query_delete_kost = "DELETE FROM kost WHERE id_kost='$id_kost'";
        $data_kost = mysqli_query($koneksi, $query_delete_kost);

        if ($data_kost) {
            // Commit transaksi jika kedua penghapusan berhasil
            mysqli_commit($koneksi);
            echo "Record deleted successfully.<br>";
            header("location:../properti.php");
            exit();
        } else {
            // Rollback transaksi jika penghapusan di tabel 'kost' gagal
            mysqli_rollback($koneksi);
            echo "Error deleting record in 'kost': " . mysqli_error($koneksi) . "<br>";
            header("location:../index.php");
            exit();
        }
    } else {
        // Rollback transaksi jika penghapusan di tabel 'kamar' gagal
        mysqli_rollback($koneksi);
        echo "Error deleting record in 'kamar': " . mysqli_error($koneksi) . "<br>";
        header("location:../index.php");
        exit();
    }
} else {
    echo "No id_kost parameter provided.<br>";
    header("location:../index.php");
    exit();
}
