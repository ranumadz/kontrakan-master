<?php
include "template/header.php";

// Periksa apakah koneksi telah sukses dibuat sebelumnya
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Tampilkan pengguna yang belum diverifikasi
$query = "SELECT * FROM user WHERE status_verifikasi = 0";
$data = mysqli_query($koneksi, $query);

?>

<div class="container">
    <table class="table table-striped table-bordered table-hover">
        <thead class="thead-dark">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Lengkap</th>
                <th scope="col">Username</th>
                <th scope="col">Password</th>
                <th scope="col">Roles</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $n = 0;
            while ($d = mysqli_fetch_array($data)) {
                $n++;
            ?>
                <tr>
                    <td><?php echo $n ?></td>
                    <td><?php echo $d['nama_lengkap'] ?></td>
                    <td><?php echo $d['username'] ?></td>
                    <td><?php echo $d['password'] ?></td>
                    <td><?php echo $d['roles'] ?></td>
                    <td>
                        <!-- <a href="php/verifikasi-user.php?id=<?php echo $d['id']; ?>&action=Setujui"><button class="btn btn-success">Setujui</button></a> -->
                        <a href="php/hapus-user.php?id=<?php echo $d['id']; ?>&action=hapus"><button class="btn btn-danger">Hapus</button></a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>


<?php
include "template/footer.php"
?>