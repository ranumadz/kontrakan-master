<?php
include "template/header.php";
$data = mysqli_query($koneksi, "SELECT * FROM kost INNER JOIN user WHERE kost.id_pemilik=user.id");

?>
<div class="container">

    <div class="container">
        <h2>Daftar Seluruh Kontrakan</h2>
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Kontrakan</th>
                    <th scope="col">Pemilik</th>
                    <th scope="col">Jumlah Kamar</th>
                    <th scope="col">Kota</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $n = 0;
                while ($d = mysqli_fetch_array($data)) {
                    $n++;
                ?>
                    <tr>
                        <td><?php echo $n ?></td>
                        <td><?php echo $d['nama_kost'] ?></td>
                        <td><?php echo $d['nama_lengkap'] ?></td>
                        <td><?php echo $d['jumlah_kamar'] ?></td>
                        <td><?php echo $d['provinsi'] . ", " . $d['kota'] ?></td>
                        <td>
                            <a href="php/hapus.php?id_kost=<?php echo $d['id_kost'] ?>" class="btn btn-danger">Hapus</a>
                            <a href="properti-edit.php?id_kost=<?php echo $d['id_kost'] ?>" class="btn btn-dark">Ubah</a>
                            <a href="tampilan-kost.php?id_kost=<?php echo $d['id_kost']; ?>" class="btn btn-warning">Detail</a>
                            <a href="tampilan-kost.php?id_kost=<?php echo $d['id_kost']; ?>" class="btn btn-primary">Verifikasi</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>


</div>




<?php

include "template/footer.php";
?>