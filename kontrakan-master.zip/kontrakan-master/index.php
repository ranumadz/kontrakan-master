<?php
include "template/header.php";

// Function to fetch the minimum facility cost for a given kost
function minfas($idkost, $tipe_kost)
{
  global $koneksi;
  $cost = mysqli_query($koneksi, "SELECT MIN(biaya_fasilitas) FROM kamar WHERE id_kost=$idkost");
  $p = mysqli_fetch_array($cost);
  return $tipe_kost == "Bulan" ? $p['MIN(biaya_fasilitas)'] : $p['MIN(biaya_fasilitas)'] * 12;
}

// Pagination setup
$jumlah_data_perhalaman = 8;
$jumlah_data = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM kost JOIN user ON kost.id_pemilik = user.id"));
$jumlah_halaman = ceil($jumlah_data / $jumlah_data_perhalaman);
$halaman_aktif = isset($_GET['halaman']) ? $_GET['halaman'] : 1;
$awalData = ($jumlah_data_perhalaman * $halaman_aktif) - $jumlah_data_perhalaman;

// Fetch data
$query = "SELECT * FROM kost JOIN user ON kost.id_pemilik = user.id LIMIT $awalData, $jumlah_data_perhalaman";
$data = mysqli_query($koneksi, $query);

?>

<style>
  .kost-card {
    background-color: red;
  }

  .checked {
    color: orange;
  }

  .card {
    margin: 6px;
  }

  .card-img-top {
    width: 100%;
    height: 15vw;
    object-fit: cover;
  }
</style>

<div class="container">
  <div class="row">
    <div class="col bg-danger rounded-lg" style="color:white">
      <form action="daftar-kost.php" method="get">
        <br>
        <div class="row">
          <div class="col my-auto">
            <div class="input-group">
              <input placeholder="Cari Kontrakan sekarang" autofocus autocomplete="off" type="text" name="cari" class="form-control border-0 small">
              <div class="input-group-append">
                <button type="submit" value="cari" class="btn btn-primary"><i class="fas fa-search fa-sm"></i></button>
              </div>
            </div>
            <br>
          </div>
          <div class="col-md-2"></div>
        </div>
        <div class="row">
          <div class="col-md-2">
            Provinsi :
            <select class="form-control" name="provinsi" id="provinsi">
              <option value=""></option>
              <?php
              $query2 = "SELECT provinsi FROM kost GROUP BY provinsi";
              $data2 = mysqli_query($koneksi, $query2);
              while ($n = mysqli_fetch_array($data2)) {
                echo "<option value='{$n['provinsi']}'>{$n['provinsi']}</option>";
              }
              ?>
            </select>
          </div>
          <div class="col-md-2">
            Kota :
            <select class="form-control" name="kota" id="kota">
              <option value=""></option>
              <?php
              $query2 = "SELECT kota FROM kost GROUP BY kota";
              $data2 = mysqli_query($koneksi, $query2);
              while ($n = mysqli_fetch_array($data2)) {
                echo "<option value='{$n['kota']}'>{$n['kota']}</option>";
              }
              ?>
            </select>
          </div>
          <div class="col-md-2">
            Jenis Kontrakan:
            <select class="form-control" name="jenis_kost" id="jenis_kost">
              <option value=""></option>
              <?php
              $query3 = "SELECT jenis_kost FROM kost GROUP BY jenis_kost";
              $data3 = mysqli_query($koneksi, $query3);
              while ($l = mysqli_fetch_array($data3)) {
                echo "<option value='{$l['jenis_kost']}'>{$l['jenis_kost']}</option>";
              }
              ?>
            </select>
          </div>
          <div class="col-md-2">
            Sort :
            <select class="form-control" name="filter_harga" id="filter_harga">
              <option value=""></option>
              <option value="1">Harga termurah</option>
              <option value="2">Harga termahal</option>
            </select>
          </div>
      </form>
    </div>
  </div>
  <br>

  <?php
  // Algoritma Pagination untuk membagi page
  $jumlah_data_perhalaman = 6;
  $jumlah_halaman = ceil($jumlah_data = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM kost JOIN user ON kost.id_pemilik = user.id")) / $jumlah_data_perhalaman);
  if (isset($_GET['halaman'])) {
    $halaman_aktif = $_GET['halaman'];
  } else {
    $halaman_aktif = 1;
  }
  $awalData = ($jumlah_data_perhalaman * $halaman_aktif) - $jumlah_data_perhalaman;

  if (isset($_GET['cari'])) {
    $cari = $_GET['cari'];
    $provinsi = $_GET['provinsi'];
    $kota = $_GET['kota'];
    $jenis_kost = $_GET['jenis_kost'];
    $filter_harga = $_GET['filter_harga'];
    $sub_query = $filter_harga == 1 ? "ORDER BY kost.harga_sewa ASC" : "ORDER BY kost.harga_sewa DESC";

    $data = mysqli_query($koneksi, "SELECT * FROM kost JOIN user ON kost.id_pemilik = user.id WHERE nama_kost LIKE '%$cari%' AND provinsi LIKE '%$provinsi%' AND kota LIKE '%$kota%' AND jenis_kost LIKE '%$jenis_kost%' $sub_query LIMIT $awalData, $jumlah_data_perhalaman");
  } else {
    $data = mysqli_query($koneksi, "SELECT * FROM kost JOIN user ON kost.id_pemilik = user.id LIMIT $awalData, $jumlah_data_perhalaman");
  }
  ?>

  <div class="container">
    <div class="col">
      <hr>
      <div class="row">
        <?php while ($d = mysqli_fetch_array($data)) { ?>
          <div class="card" style="width: 18rem;">
            <a style="text-decoration: none; color: black;" href="tampilan-kost.php?id_kost=<?php echo $d['id_kost'] ?>">
              <div class="card-header">
                <div class="row">
                  <div class="col-md-3"></div>
                  <div class="col">
                    <div class="card-text">
                      <h6 class="card-title font-weight-bold mb-1"><?php echo $d['nama_kost'] ?></h6>
                      <span class="stars-active" style="width:50%">
                        <i class="fa fa-star checked" aria-hidden="true"></i>
                        <i class="fa fa-star checked" aria-hidden="true"></i>
                        <i class="fa fa-star checked" aria-hidden="true"></i>
                        <i class="fa fa-star checked" aria-hidden="true"></i>
                        <i class="fa fa-star-half-alt checked" aria-hidden="true"></i>
                      </span>
                      <p class="card-text"><i class="fas fa-map-marker-alt"></i> <?php echo $d['kota'] . ',' . $d['provinsi'] ?></p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="row">
                  <img class="card-img-top mx-auto" src="../img/foto_kost/kamar/<?php echo $d['foto_kamar'] ?>" alt="Card image cap">
                </div>
              </div>
              <div class="card-footer">
                <div class="row">
                  <div class="col-md-7" style="font-size:12px;font-weight:bold"><?php echo number_format($d['harga_sewa'] + minfas($d['id_kost'], $d['tipe_kost']), 0, ',', '.') . '/' . $d['tipe_kost'] ?></div>
                  <?php
                  $jenis_kost_class = $d['jenis_kost'] == "Tipe C" ? "pink" : ($d['jenis_kost'] == "Tipe B" ? "black" : "purple");
                  ?>
                  <div class="col" style="background-color:<?php echo $jenis_kost_class; ?>; font-size:12px; font-weight:bold; color:white"><?php echo $d['jenis_kost'] ?></div>
                </div>
              </div>
            </a>
          </div>
        <?php } ?>
      </div>
      <hr>
      <div class="row">
        <?php for ($i = 1; $i <= $jumlah_halaman; $i++) : ?>
          <?php if ($i == $halaman_aktif) : ?>
            <a style="font-weight: bold;background-color:black;padding:10px;color:white;" href="?halaman=<?php echo $i ?>"><?php echo $i ?></a>
          <?php else : ?>
            <a style="font-weight: bold;background-color:red;padding:10px;color:white" href="?halaman=<?php echo $i ?>"><?php echo $i ?></a>
          <?php endif; ?>
        <?php endfor; ?>
      </div>
    </div>



    </body>

    <?php
    include "template/footer.php";
    ?>